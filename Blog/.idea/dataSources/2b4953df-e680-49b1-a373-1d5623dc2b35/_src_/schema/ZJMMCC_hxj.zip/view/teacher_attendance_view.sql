CREATE VIEW ZJMMCC_hxj.teacher_attendance_view AS
  (SELECT
     `tb1`.`m_id`                   AS `m_id`,
     `tb1`.`delay_count`            AS `delay_count`,
     ifnull(`tb2`.`early_count`, 0) AS `early_count`
   FROM ((SELECT
            `tbl1`.`m_id`                   AS `m_id`,
            ifnull(`tbl2`.`delay_count`, 0) AS `delay_count`
          FROM (`ZJMMCC_hxj`.`tbl_month` `tbl1` LEFT JOIN (SELECT
                                                             `ZJMMCC_hxj`.`tbl_attendance_log`.`teacher_id`        AS `teacher_id`,
                                                             count(
                                                                 0)                                                AS `delay_count`,
                                                             month(
                                                                 `ZJMMCC_hxj`.`tbl_attendance_log`.`start_time`)   AS `month`
                                                           FROM `ZJMMCC_hxj`.`tbl_attendance_log`
                                                           WHERE (((`ZJMMCC_hxj`.`tbl_attendance_log`.`section` = 1) AND
                                                                   (time_to_sec(
                                                                        `ZJMMCC_hxj`.`tbl_attendance_log`.`start_time`)
                                                                    > time_to_sec('08:00:00'))) OR
                                                                  ((`ZJMMCC_hxj`.`tbl_attendance_log`.`section` = 2) AND
                                                                   (time_to_sec(
                                                                        `ZJMMCC_hxj`.`tbl_attendance_log`.`start_time`)
                                                                    > time_to_sec('10:20:00'))) OR
                                                                  ((`ZJMMCC_hxj`.`tbl_attendance_log`.`section` = 3) AND
                                                                   (time_to_sec(
                                                                        `ZJMMCC_hxj`.`tbl_attendance_log`.`start_time`)
                                                                    > time_to_sec('14:00:00'))) OR
                                                                  ((`ZJMMCC_hxj`.`tbl_attendance_log`.`section` = 4) AND
                                                                   (time_to_sec(
                                                                        `ZJMMCC_hxj`.`tbl_attendance_log`.`start_time`)
                                                                    > time_to_sec('16:20:00'))) OR
                                                                  ((`ZJMMCC_hxj`.`tbl_attendance_log`.`section` = 5) AND
                                                                   (time_to_sec(
                                                                        `ZJMMCC_hxj`.`tbl_attendance_log`.`start_time`)
                                                                    > time_to_sec('20:00:00'))))
                                                           GROUP BY `ZJMMCC_hxj`.`tbl_attendance_log`.`teacher_id`,
                                                             month(`ZJMMCC_hxj`.`tbl_attendance_log`.`start_time`)
                                                           HAVING (`ZJMMCC_hxj`.`tbl_attendance_log`.`teacher_id` =
                                                                   96)) `tbl2`
              ON ((`tbl1`.`m_id` = `tbl2`.`month`)))) `tb1` LEFT JOIN (SELECT
                                                                         `ZJMMCC_hxj`.`tbl_attendance_log`.`teacher_id`      AS `teacher_id`,
                                                                         count(
                                                                             0)                                              AS `early_count`,
                                                                         month(
                                                                             `ZJMMCC_hxj`.`tbl_attendance_log`.`start_time`) AS `month`
                                                                       FROM `ZJMMCC_hxj`.`tbl_attendance_log`
                                                                       WHERE (((
                                                                                 `ZJMMCC_hxj`.`tbl_attendance_log`.`section`
                                                                                 = 1) AND (time_to_sec(
                                                                                               `ZJMMCC_hxj`.`tbl_attendance_log`.`end_time`)
                                                                                           < time_to_sec('10:00:00')))
                                                                              OR ((
                                                                                    `ZJMMCC_hxj`.`tbl_attendance_log`.`section`
                                                                                    = 2) AND (time_to_sec(
                                                                                                  `ZJMMCC_hxj`.`tbl_attendance_log`.`end_time`)
                                                                                              <
                                                                                              time_to_sec('12:20:00')))
                                                                              OR ((
                                                                                    `ZJMMCC_hxj`.`tbl_attendance_log`.`section`
                                                                                    = 3) AND (time_to_sec(
                                                                                                  `ZJMMCC_hxj`.`tbl_attendance_log`.`end_time`)
                                                                                              <
                                                                                              time_to_sec('16:00:00')))
                                                                              OR ((
                                                                                    `ZJMMCC_hxj`.`tbl_attendance_log`.`section`
                                                                                    = 4) AND (time_to_sec(
                                                                                                  `ZJMMCC_hxj`.`tbl_attendance_log`.`end_time`)
                                                                                              <
                                                                                              time_to_sec('18:20:00')))
                                                                              OR ((
                                                                                    `ZJMMCC_hxj`.`tbl_attendance_log`.`section`
                                                                                    = 5) AND (time_to_sec(
                                                                                                  `ZJMMCC_hxj`.`tbl_attendance_log`.`end_time`)
                                                                                              <
                                                                                              time_to_sec('22:00:00'))))
                                                                       GROUP BY
                                                                         `ZJMMCC_hxj`.`tbl_attendance_log`.`teacher_id`,
                                                                         month(
                                                                             `ZJMMCC_hxj`.`tbl_attendance_log`.`start_time`)
                                                                       HAVING (
                                                                         `ZJMMCC_hxj`.`tbl_attendance_log`.`teacher_id`
                                                                         = 96)) `tb2`
       ON ((`tb1`.`m_id` = `tb2`.`month`))));
